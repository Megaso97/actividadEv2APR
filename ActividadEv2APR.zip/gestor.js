let inputNombre=document.querySelector("#input_nombre");
let inputApellido=document.querySelector("input#input_apellido");
let inputCorreo=document.querySelector("input#input_correo");
let select=document.querySelector("select#select");
let boton=document.querySelector("#boton");
let boton_segundo=document.querySelector("#boton-busqueda")
let lista_Trabajadores_Datos =[];
let select_segundo=document.querySelector("select#select-segundo")
let ListaFiltro = document.querySelector("#lista_filtrado");
boton.addEventListener("click",()=>{

  if(inputNombre.value.length > 0 && inputApellido.value.length>0 && inputCorreo.value.length>0){
    lista_Trabajadores_Datos.push(`${inputNombre.value};${inputApellido.value}${inputCorreo.value} ${select.value}`);
    console.log(lista_Trabajadores_Datos);
   let nodo = document.createElement("li");
   nodo.textContent=`${inputNombre.value} ${inputApellido.value}`;
   listaTrabajadores.classList.add( "list-group-item");
   listaTrabajadores.append(nodo);
   inputNombre.value="";
    inputApellido.value="";
    inputCorreo.value="";
    Swal.fire({
        title: "Buen trabajo",
        text: "El trabajador ha sido agregado correctamente",
        icon: "success"
      });
  }
  else {
    Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Algun campo esta incompleto",
      });
  }
})
 boton_segundo.addEventListener("click", () => {
    let listaDelFiltro = lista_Trabajadores_Datos;
    console.log(listaDelFiltro);
    ListaFiltro.innerHTML="";
    switch (select_segundo.value) {
        case "IT":
            console.log(listaDelFiltro);
            listaDelFiltro.forEach((item) => {
                if (item.includes("IT")) {
                    let nodo2 = document.createElement("li");
                    nodo2.textContent = "";
                    nodo2.textContent = item;
                    nodo2.classList.add("list-group-item")
                    ListaFiltro.append(nodo2);
                }
            });
            break;
        case "Marketing":
            console.log(listaDelFiltro);
            listaDelFiltro.forEach((item) => {
                if (item.includes("Marketing")) {
                    let nodo2 = document.createElement("li");
                    nodo2.textContent = "";
                    nodo2.textContent = item;
                    nodo2.classList.add("list-group-item")
                    ListaFiltro.append(nodo2);
                }
            });
            break;
        case "Ventas":
            console.log(listaDelFiltro);
            listaDelFiltro.forEach((item) => {
                if (item.includes("Ventas")) {
                    let nodo2 = document.createElement("li");
                    nodo2.textContent = "";
                    nodo2.textContent = item;
                    nodo2.classList.add("list-group-item")
                    ListaFiltro.append(nodo2);
                }
            });
            break;
        case "Administracion":
            console.log(listaDelFiltro);
            listaDelFiltro.forEach((item) => {
                if (item.includes("Administracion")) {
                    let nodo2 = document.createElement("li");

                    nodo2.textContent = "";
                    nodo2.textContent = item;
                    nodo2.classList.add("list-group-item")
                    ListaFiltro.append(nodo2);
                }
            });
            break;
        default:
            console.log("Opción no válida");
    }
});
   
    
  
        
  


    
  
